http = require('http');

var server = http.createServer( function(req, res) {
    if (req.method == 'POST') {
        // console.log("POST");
        var body = '';
        req.on('data', function (data) {
            console.log(Date());
            console.log(data.toString());
        });
        req.on('end', function () {
        });
        res.writeHead(200, {'Content-Type': 'text/html'});
        res.end('');
    }
    else
    {
        console.log("GET");
        res.writeHead(200, {'Content-Type': 'text/html'});
        res.end('');
        }
});

server.listen(8081);
console.log("Running at Port 8081");