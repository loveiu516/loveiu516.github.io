﻿var request = require('request');
var parseString = require('xml2js').parseString;
var mqtt = require('mqtt');

var DeviceId = "DfdnMZaT";
var DeviceKey = "L3a0PyUu6yIXBGSQ";

var sp_2101w_ip = "192.168.1.118";

var nowpowerxml = '<?xml version="1.0" encoding="UTF8"?><SMARTPLUG id="edimax"><CMD id="get"><NOW_POWER></NOW_POWER></CMD></SMARTPLUG>';
var poweronxml = '<?xml version="1.0" encoding="UTF8"?><SMARTPLUG id="edimax"><CMD id="setup"><Device.System.Power.State>ON</Device.System.Power.State></CMD></SMARTPLUG>';
var poweroffxml = '<?xml version="1.0" encoding="UTF8"?><SMARTPLUG id="edimax"><CMD id="setup"><Device.System.Power.State>OFF</Device.System.Power.State></CMD></SMARTPLUG>';

function main() {
    request({
        url: "http://admin:1234@" + sp_2101w_ip + ":10000/smartplug.cgi",
        method: "POST",
        headers: {},
        body: nowpowerxml
    }, function (error, response, body) {
        if (error) {
            console.log(error);
        } else {
            parseString(body, function (err, result) {
                power = result.SMARTPLUG.CMD[0].NOW_POWER[0]["Device.System.Power.NowPower"][0];
                console.log(power);
                client.publish('mcs/' + DeviceId + '/' + DeviceKey + '/ww', ',ww,' + parseFloat(power), { qos: 0 });
            });
        }
    });
    setTimeout(main, 60000);
}
main();

function initMQTT() {
    var settings = {
        clientId: 'client-' + new Date().getTime(),
        port: 1883,
        host: 'mqtt.mcs.mediatek.com',
    };
    client = mqtt.connect(settings);
    client.on('connect', function () {
        client.subscribe('mcs/' + DeviceId + '/' + DeviceKey + '/switch1');

    });
    client.on('message', function (topic, message) {

        if (topic == 'mcs/' + DeviceId + '/' + DeviceKey + '/switch1') {
            if (message.toString().split(',')[2] == "1") {

                request({
                    url: "http://admin:1234@" + sp_2101w_ip + ":10000/smartplug.cgi",
                    method: "POST",
                    headers: {},
                    body: poweronxml
                }, function (error, response, body) {
                    if (error) {
                        console.log(error);
                    } else {
                        console.log(body);
                    }
                });


            }
            if (message.toString().split(',')[2] == "0") {
                
                
                request({
                    url: "http://admin:1234@" + sp_2101w_ip + ":10000/smartplug.cgi",
                    method: "POST",
                    headers: {},
                    body: poweroffxml
                }, function (error, response, body) {
                    if (error) {
                        console.log(error);
                    } else {
                        console.log(body);
                    }
                });

            }
        }

    });
    client.on('reconnect', function () {
        // console.log('reconnect');
    });
}
initMQTT();