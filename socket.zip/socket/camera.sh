killall mjpg_streamer
sleep 2
mjpg_streamer -i "input_uvc.so -r 1280*960 -d /dev/video0" -o "output_http.so -n" -b