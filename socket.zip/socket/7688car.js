var http = require('http');
var url = require('url');

var tmp = "";
var cmd = "";

var SerialPort = require("serialport").SerialPort;
var serialPort = new SerialPort("/dev/ttyS0", {
    baudrate: 57600
});

var server = http.createServer(function(req,res){
    var params = url.parse(req.url, true).query;

    if (params.cmd=="stop" || params.cmd=="forward" || params.cmd=="back" || params.cmd=="left" || params.cmd=="right") {
    	cmd = params.cmd;
    	// console.log(cmd);
    	serialPort.write(cmd.substring(0,2));
    	cmd = "";
    	tmp = "OK";
    }
    
    res.writeHead(200,{'Content-Type': 'text/html'});
    res.write(tmp);
    res.end();
    tmp = "";
    });

server.listen(8081);
console.log("Running at Port 8081");