var http = require('http');
var fs = require('fs');
var io = require('socket.io');

var SerialPort = require("serialport").SerialPort;
var serialPort = new SerialPort("/dev/ttyS0", {
    baudrate: 57600
});

var server = http.createServer(function(req, res){
    fs.readFile('index.html',function (err, index){
        res.writeHead(200, {'Connection':'keep-alive','Content-Type':'text/html; charset=UTF-8','Content-Length':index.length});
        res.write(index);
        res.end();
    });
})

server.listen(8081);
console.log("Running at Port 8081");

io.listen(server).sockets.on('connection', function(socket){
	socket.on('cmd message', function(cmd){
		console.log(cmd);
		serialPort.write(cmd);
	});
});