var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);


var SerialPort = require("serialport").SerialPort;
var serialPort = new SerialPort("/dev/ttyS0", {
    baudrate: 57600
});


app.get('/', function(req, res){
  res.sendFile(__dirname + '/index.html');
});

io.on('connection', function(socket){
  socket.on('cmd message', function(cmd){
  	console.log(cmd);
    io.emit('cmd message', cmd);
    serialPort.write(cmd)
  });
});

http.listen(8081, function(){
  console.log('listening on 8081');
});