var http = require('http');
var url = require("url");
var path = require("path");
var fs = require('fs');
var io = require('socket.io');


var SerialPort = require("serialport").SerialPort;
var serialPort = new SerialPort("/dev/ttyS0", {
    baudrate: 57600
});


var mimes = {
    ".html":"text/html",
    ".css":"text/css",
    ".js":"text/javascript",
}


var server = http.createServer(function(req,res){
    var filepath =(req.url==='/')?('./index.html'):('.'+req.url);
    var contentType = mimes[path.extname(filepath)];

    fs.exists(filepath,function(file_exists){
        if(file_exists)
        {
                res.writeHead(200, {'Content-Type' : contentType});
                var streamFile = fs.createReadStream(filepath).pipe(res);
                streamFile.on('error',function(){
                    res.writeHead(500, {"Content-Type": "text/plain"});
                    res.write();
                    res.end();
                })
        }
        else
        {
            res.writeHead(404, {"Content-Type": "text/plain"});
            res.write("404 Not Found");
            res.end();
        }
    })
});

server.listen(8081);
console.log("Running at Port 8081");

io.listen(server).sockets.on('connection', function(socket){
	socket.on('cmd message', function(cmd){
		// console.log(cmd);
		serialPort.write(cmd);
	});
});