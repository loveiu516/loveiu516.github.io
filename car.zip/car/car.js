var http = require('http');
var url = require("url");
var path = require("path");
var fs = require('fs');

var SerialPort = require("serialport").SerialPort;
var serialPort = new SerialPort("/dev/ttyS0", {
    baudrate: 57600
});

var mimes = {
    ".html":"text/html",
    ".css" :"text/css",
    ".js"  :"text/javascript"
}

var tmp = "";
var cmd = "";

var server = http.createServer(function(req,res){
    var params = url.parse(req.url, true).query;
    
    if (params.cmd != 'undefined') {
        console.log(params.cmd);
        if (params.cmd=="stop" || params.cmd=="forward" || params.cmd=="back" || params.cmd=="left" || params.cmd=="right") {
            cmd = params.cmd;
            // console.log(cmd);
            serialPort.write(cmd.substring(0,2));
            cmd = "";
            tmp = "OK";
            res.writeHead(200, {"Content-Type":"text/html; charset=UTF-8"});
            res.write(tmp);
            res.end();
        }
    }

    if (params.servo1 != 'undefined') {
        console.log(params.servo1);
        if (parseInt(params.servo1.substring(2))<181) {
            console.log("s1:" + cmd.substring(2));
            serialPort.write(cmd.substring(2));
            cmd = "";
            tmp = "OK";
            res.writeHead(200, {"Content-Type":"text/html; charset=UTF-8"});
            res.write(tmp);
            res.end();
        }
    }

    if (params.servo2 != 'undefined') {
        console.log(params.servo2);
        if (parseInt(params.servo2.substring(2))<181) {
            console.log("s2:" + cmd.substring(2));
            serialPort.write(cmd.substring(2));
            cmd = "";
            tmp = "OK";
            res.writeHead(200, {"Content-Type":"text/html; charset=UTF-8"});
            res.write(tmp);
            res.end();
        }
    }

    else{


    var filepath =(req.url==='/')?('./index.html'):('./'+req.url);
    var contentType = mimes[path.extname(filepath)];

    fs.exists(filepath,function(file_exists){
        if(file_exists)
        {
            res.writeHead(200, {'Content-Type' : contentType});
            var streamFile = fs.createReadStream(filepath).pipe(res);
            streamFile.on('error',function(){
                res.writeHead(500, {"Content-Type":"text/plain"});
                res.write();
                res.end();
                tmp = "";
            })
        }
        else
        {
            res.writeHead(404, {"Content-Type":"text/plain"});
            res.write("404 Not Found");
            res.end();
        }
    })

    }
});

server.listen(8081);
console.log("Running at Port 8081");


function cameraon() {
    var exec = require('child_process').exec;
    var cmd = exec('mjpg_streamer -i "input_uvc.so -r 1280*960 -d /dev/video0" -o "output_http.so -n"');

    cmd.stdout.on('data', function(data) {
      console.log('stdout: ' + data);
    });
    cmd.stderr.on('data', function(data) {
      console.log('stdout: ' + data);
    });
    cmd.on('close', function(code) {
      console.log('closing code: ' + code);
    });
}

function cameraoff() {
    var exec = require('child_process').exec;
    var cmd = exec('killall mjpg_streamer');

    cmd.stdout.on('data', function(data) {
      console.log('stdout: ' + data);
    });
    cmd.stderr.on('data', function(data) {
      console.log('stdout: ' + data);
    });
    cmd.on('close', function(code) {
      console.log('closing code: ' + code);
    });
}